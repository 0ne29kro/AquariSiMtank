# 🚀 QUICK START FOR CLASSMATES

## I just want to run the aquarium! What do I do?

### If you received a .zip file with an .exe:

1. **Extract the zip file** (right-click → Extract All)
2. **Open the extracted folder**
3. **Double-click** `CoralReefAquarium.exe`
4. **Done!** The aquarium should start 🎉

> If Windows shows a security warning:
> - Click "More info"
> - Click "Run anyway"
> - This is normal for programs that aren't digitally signed

---

### If you received just the Python file (.py):

You'll need Python installed. Here's the simplest way:

1. **Install Python:**
   - Go to [python.org/downloads](https://python.org/downloads)
   - Download Python (3.8 or newer)
   - **IMPORTANT:** Check "Add Python to PATH" during installation

2. **Open Command Prompt (Windows) or Terminal (Mac/Linux):**
   - Windows: Press `Win + R`, type `cmd`, press Enter
   - Mac: Press `Cmd + Space`, type `terminal`, press Enter

3. **Install pygame:**
   ```
   pip install pygame
   ```
   
   Wait for it to finish (might take a minute)

4. **Run the aquarium:**
   - Navigate to the folder with the .py file
   - Type: `python aquarium__6_.py`
   - Press Enter

---

## Need help?

Ask the person who shared this with you! They built this awesome aquarium 🐠

## Controls

- **Click** anywhere to feed the fish
- **F** to change fish styles
- **B** to see background scenes
- **W** to clean the water
- **H** to hide/show the UI
- **ESC** to exit
